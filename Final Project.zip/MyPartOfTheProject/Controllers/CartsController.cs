﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Data;
using MyPartOfTheProject.Models;

namespace MyPartOfTheProject.Controllers
{
    public class CartController : Controller
    {
        private readonly DataContext _context;

        public CartController(DataContext context)
        {
            _context = context;
        }
        [Authorize]
        public async Task<IActionResult> Index()
        {
            int orderId = GetOrCreateCartOrderId();

            var cartItems = await _context.OrderItems
                .Include(oi => oi.Product)
                .ThenInclude(p => p!.Category)
                .Where(oi => oi.OrderId == orderId)
                .ToListAsync();

            return View(cartItems);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddToCart(int productId)
        {
            int orderId = GetOrCreateCartOrderId();

            var existingItem = await _context.OrderItems
                .FirstOrDefaultAsync(oi => oi.OrderId == orderId && oi.ProductId == productId);

            if (existingItem == null)
            {
                var orderItem = new OrderItem
                {
                    OrderId = orderId,
                    ProductId = productId,
                    Quantity = 1
                };

                _context.OrderItems.Add(orderItem);
            }
            else
            {
                existingItem.Quantity++;
                _context.OrderItems.Update(existingItem);
            }

            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Increase(int id)
        {
            var item = await _context.OrderItems.FindAsync(id);

            if (item != null)
            {
                item.Quantity++;
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Decrease(int id)
        {
            var item = await _context.OrderItems.FindAsync(id);

            if (item != null)
            {
                if (item.Quantity > 1)
                {
                    item.Quantity--;
                }
                else
                {
                    _context.OrderItems.Remove(item);
                }

                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(int id)
        {
            int orderId = GetOrCreateCartOrderId();

            var item = await _context.OrderItems
                .FirstOrDefaultAsync(oi => oi.OrderItemId == id && oi.OrderId == orderId);

            if (item != null)
            {
                _context.OrderItems.Remove(item);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }
        private int GetOrCreateCartOrderId()
        {
            int? orderId = HttpContext.Session.GetInt32("CartOrderId");

            if (orderId != null)
            {
                return orderId.Value;
            }

            var order = new Order
            {
                CustomerName = "Guest",
                OrderDate = DateTime.Now
            };

            _context.Orders.Add(order);
            _context.SaveChanges();

            HttpContext.Session.SetInt32("CartOrderId", order.OrderId);

            return order.OrderId;
        }
    }
}