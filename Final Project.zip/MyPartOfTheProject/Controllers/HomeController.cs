﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Data;

namespace MyPartOfTheProject.Controllers
{
    public class HomeController : Controller
    {

        private readonly DataContext _context;

        public HomeController(DataContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var products = _context.Products
               .Include(p => p.Category)
               .Where(p => p.ProductId == 2
                 || p.ProductId == 7
                 || p.ProductId == 25)
               .ToList();

            return View(products);
        }
    }
}
