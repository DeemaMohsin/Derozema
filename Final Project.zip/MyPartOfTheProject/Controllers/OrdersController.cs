﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Data;

namespace MyPartOfTheProject.Controllers
{
    public class OrdersController : Controller
    {
        private readonly DataContext _context;

        public OrdersController(DataContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Checkout()
        {
            int? orderId = HttpContext.Session.GetInt32("CartOrderId");

            if (orderId == null)
            {
                return View(new List<MyPartOfTheProject.Models.OrderItem>());
            }

            var items = await _context.OrderItems
                .Include(oi => oi.Product)
                .ThenInclude(p => p!.Category)
                .Where(oi => oi.OrderId == orderId.Value)
                .ToListAsync();

            return View(items);
        }









        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult PlaceOrder()
        {
            return RedirectToAction(nameof(Complete));
        }





        
        public async Task<IActionResult> Complete()
        {
            int? orderId = HttpContext.Session.GetInt32("CartOrderId");

            if (orderId == null)
            {
                return RedirectToAction("Index", "Cart");
            }

            var items = await _context.OrderItems
                .Include(o => o.Product)
                .Where(o => o.OrderId == orderId.Value)
                .ToListAsync();

            decimal subtotal = items.Sum(i => i.Product!.Price * i.Quantity);

            decimal deliveryFee = subtotal > 0 ? 2.00m : 0.00m;

            decimal tax = subtotal * 0.10m;

            decimal total = subtotal + deliveryFee + tax;

            ViewData["Total"] = total.ToString("0.000") + " JOD";
            HttpContext.Session.Remove("CartOrderId");
            return View();
        }
    }
}