﻿using Microsoft.AspNetCore.Mvc;

namespace MyPartOfTheProject.Controllers
{
    public class AboutUsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
