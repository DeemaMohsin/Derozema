﻿using Microsoft.AspNetCore.Mvc;

namespace MyPartOfTheProject.Controllers
{
    public class ReviewsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
