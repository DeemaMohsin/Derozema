using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Data;
using MyPartOfTheProject.Models;
using Microsoft.AspNetCore.Authorization;

public class ProductsController : Controller
{
    private readonly DataContext _context;

    public ProductsController(DataContext context)
    {
        _context = context;
    }


    [AllowAnonymous]
    [Route("Products")]
    public async Task<IActionResult> Index(string sort)
    {
        IQueryable<Product> products = _context.Products.Include(p => p.Category);

        if (sort == "low")
        {
            products = products.OrderBy(p => p.Price);
        }
        else if (sort == "high")
        {
            products = products.OrderByDescending(p => p.Price);
        }

        return View(await products.ToListAsync());
    }

    [Authorize(Roles = "Admin")]
    [Route("[controller]/[action]/{id}")]
    public async Task<IActionResult> Details(int? id, int? productid)
    {
        int? productKey = id ?? productid;

        if (productKey == null)
        {
            return NotFound();
        }

        var product = await _context.Products
            .Include(p => p.Category)
            .FirstOrDefaultAsync(m => m.ProductId == productKey);

        if (product == null)
        {
            return NotFound();
        }

        return View(product);
    }

    [Authorize(Roles = "Admin")]
    public IActionResult Create()
    {
        ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName");
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Create([Bind("ProductId,ProductName,ProductDescription,Price,ImageUrl,CategoryId,Rating")] Product product)
    {
        if (ModelState.IsValid)
        {
            _context.Products.Add(product);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
        return View(product);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int? id, int? productid)
    {
        int? productKey = id ?? productid;

        if (productKey == null)
        {
            return NotFound();
        }

        var product = await _context.Products.FindAsync(productKey);

        if (product == null)
        {
            return NotFound();
        }

        ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
        return View(product);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Edit(int? id, int? productid, [Bind("ProductId,ProductName,ProductDescription,Price,ImageUrl,CategoryId,Rating")] Product product)
    {
        int? productKey = id ?? productid;

        if (productKey != product.ProductId)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                _context.Products.Update(product);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProductExists(product.ProductId))
                {
                    return NotFound();
                }

                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        ViewData["CategoryId"] = new SelectList(_context.Categories, "CategoryId", "CategoryName", product.CategoryId);
        return View(product);
    }

    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Delete(int? id, int? productid)
    {
        int? productKey = id ?? productid;

        if (productKey == null)
        {
            return NotFound();
        }

        var product = await _context.Products
            .Include(p => p.Category)
            .FirstOrDefaultAsync(m => m.ProductId == productKey);

        if (product == null)
        {
            return NotFound();
        }

        return View(product);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> DeleteConfirmed(int? id, int? productid)
    {
        int? productKey = id ?? productid;

        var product = await _context.Products.FindAsync(productKey);

        if (product != null)
        {
            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
        }

        return RedirectToAction(nameof(Index));
    }

    private bool ProductExists(int? productid)
    {
        return _context.Products.Any(e => e.ProductId == productid);
    }
}