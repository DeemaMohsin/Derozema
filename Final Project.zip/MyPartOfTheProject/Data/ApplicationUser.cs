﻿using Microsoft.AspNetCore.Identity;

namespace MyPartOfTheProject.Data
{
    public class ApplicationUser : IdentityUser
    {
    }
}