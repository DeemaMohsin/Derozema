using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Models;

namespace MyPartOfTheProject.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options)
            : base(options)
        {
        }

        public DbSet<Category> Categories { get; set; } = default!;
        public DbSet<Product> Products { get; set; } = default!;
        public DbSet<Order> Orders { get; set; } = default!;
        public DbSet<OrderItem> OrderItems { get; set; } = default!;
        public DbSet<Payment> Payments { get; set; } = default!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Category>().HasData(
                new Category { CategoryId = 1, CategoryName = "Jordanian", Description = "Traditional Jordanian dishes" },
                new Category { CategoryId = 2, CategoryName = "Korean", Description = "Popular Korean food" },
                new Category { CategoryId = 3, CategoryName = "Turkish", Description = "Traditional Turkish meals" },
                new Category { CategoryId = 4, CategoryName = "French", Description = "French dishes and desserts" },
                new Category { CategoryId = 5, CategoryName = "Egyptian", Description = "Classic Egyptian food" },
                new Category { CategoryId = 6, CategoryName = "Chinese", Description = "Chinese meals and snacks" },
                new Category { CategoryId = 7, CategoryName = "Chechen", Description = "Traditional Chechen food" }
            );

            modelBuilder.Entity<Product>().HasData(
                new Product { ProductId = 1, ProductName = "Mansaf", ProductDescription = "Traditional Jordanian lamb with rice and jameed sauce.", Price = 22.99m, ImageUrl = "/food-pics/jordanian-food/mansaf.jpg", CategoryId = 1 , Rating = 5 },
                new Product { ProductId = 2, ProductName = "Al-Rashoof", ProductDescription = "A warm Jordanian dish made with lentils, yogurt, and bread.", Price = 12.99m, ImageUrl = "/food-pics/jordanian-food/alrashoof.jpg", CategoryId = 1 ,Rating = 5 },
                new Product { ProductId = 3, ProductName = "Makmora", ProductDescription = "Layered Jordanian bread filled with chicken, onions, and olive oil.", Price = 15.99m, ImageUrl = "/food-pics/jordanian-food/makmora.jpg", CategoryId = 1, Rating=5},

                new Product { ProductId = 4, ProductName = "Kimbap", ProductDescription = "Korean rice rolls filled with vegetables and other ingredients.", Price = 9.99m, ImageUrl = "/food-pics/korean-food/kimbap.jpg", CategoryId = 2, Rating = 4 },
                new Product { ProductId = 5, ProductName = "Teokbokki", ProductDescription = "Spicy Korean rice cakes cooked in a sweet and spicy sauce.", Price = 10.99m, ImageUrl = "/food-pics/korean-food/teokbokki.jpg", CategoryId =2, Rating = 5 },
                new Product { ProductId = 6, ProductName = "Korean Fried Chicken", ProductDescription = "Crispy Korean fried chicken with a flavorful sauce.", Price = 14.99m, ImageUrl = "/food-pics/korean-food/friedchicken.jpg", CategoryId = 2, Rating = 5 },
                new Product { ProductId = 7, ProductName = "Kimchi Pizza", ProductDescription = "A fusion pizza topped with spicy kimchi and cheese.", Price = 13.99m, ImageUrl = "/food-pics/korean-food/kimchipizza.jpg", CategoryId = 2, Rating = 5 },

                new Product { ProductId = 8, ProductName = "Doner", ProductDescription = "Turkish meat served with bread, vegetables, and sauce.", Price = 11.99m, ImageUrl = "/food-pics/turkish-food/doner.jpg", CategoryId = 3, Rating = 5 },
                new Product { ProductId = 9, ProductName = "Kebap", ProductDescription = "Grilled Turkish meat served with rice or bread.", Price = 16.99m, ImageUrl = "/food-pics/turkish-food/kebap.jpg", CategoryId = 3, Rating = 5 },
                new Product { ProductId = 10, ProductName = "Lahmacun", ProductDescription = "Thin Turkish flatbread topped with minced meat and spices.", Price = 8.99m, ImageUrl = "/food-pics/turkish-food/lahmacun.jpg", CategoryId = 3, Rating = 5 },
                new Product { ProductId = 11, ProductName = "Manti", ProductDescription = "Turkish dumplings served with yogurt and sauce.", Price = 12.99m, ImageUrl = "/food-pics/turkish-food/manti.jpg", CategoryId = 3, Rating = 5 },
                new Product { ProductId = 12, ProductName = "Pide", ProductDescription = "Turkish boat-shaped flatbread with cheese or meat filling.", Price = 11.99m, ImageUrl = "/food-pics/turkish-food/pide.jpg", CategoryId = 3, Rating = 4 },

                new Product { ProductId = 13, ProductName = "Croissant", ProductDescription = "A buttery French pastry with a flaky golden crust.", Price = 4.99m, ImageUrl = "/food-pics/french-food/croissant.jpg", CategoryId = 4, Rating = 5 },
                new Product { ProductId = 14, ProductName = "Onion Soup", ProductDescription = "Classic French onion soup with melted cheese.", Price = 8.99m, ImageUrl = "/food-pics/french-food/onionsoup.jpg", CategoryId = 4, Rating = 5 },
                new Product { ProductId = 15, ProductName = "Ratatouille", ProductDescription = "French vegetable dish cooked with herbs and olive oil.", Price = 12.99m, ImageUrl = "/food-pics/french-food/ratatouille.jpg", CategoryId = 4, Rating = 5 },
                new Product { ProductId = 16, ProductName = "Steak Frites", ProductDescription = "French steak served with crispy fries.", Price = 24.99m, ImageUrl = "/food-pics/french-food/steakfrites.jpg", CategoryId = 4, Rating = 5 },

                new Product { ProductId = 17, ProductName = "Koshari", ProductDescription = "Egyptian dish with rice, pasta, lentils, chickpeas, and tomato sauce.", Price = 9.99m, ImageUrl = "/food-pics/egypt-food/koshari.jpg", CategoryId = 5, Rating = 4 },
                new Product { ProductId = 18, ProductName = "Ful Medames", ProductDescription = "Egyptian fava beans served with olive oil and spices.", Price = 6.99m, ImageUrl = "/food-pics/egypt-food/ful.jpg", CategoryId = 5, Rating = 4 },
                new Product { ProductId = 19, ProductName = "Fesikh", ProductDescription = "Traditional Egyptian salted fish dish.", Price = 13.99m, ImageUrl = "/food-pics/egypt-food/fesikh.jpg", CategoryId = 5, Rating = 3 },

                new Product { ProductId = 20, ProductName = "Dumplings", ProductDescription = "Chinese dumplings filled with meat or vegetables.", Price = 10.99m, ImageUrl = "/food-pics/chinese-food/dumplings.jpg", CategoryId = 6, Rating = 5 },
                new Product { ProductId = 21, ProductName = "Lambian", ProductDescription = "Chinese hand-pulled noodle dish.", Price = 12.99m, ImageUrl = "/food-pics/chinese-food/lambian.jpg", CategoryId = 6, Rating = 5 },
                new Product { ProductId = 22, ProductName = "Fried Bugs", ProductDescription = "A unique Chinese street food snack.", Price = 7.99m, ImageUrl = "/food-pics/chinese-food/friedbugs.jpg", CategoryId = 6, Rating = 1 },

                new Product { ProductId = 23, ProductName = "Chepalgash", ProductDescription = "Traditional Chechen flatbread stuffed with filling.", Price = 9.99m, ImageUrl = "/food-pics/chechen-food/chepalgash.jpg", CategoryId = 7, Rating = 5 },
                new Product { ProductId = 24, ProductName = "Galnesh", ProductDescription = "Chechen dumplings usually served with meat and garlic sauce.", Price = 15.99m, ImageUrl = "/food-pics/chechen-food/galnesh.jpg", CategoryId = 7, Rating = 4 },
                new Product { ProductId = 25, ProductName = "Kurznesh", ProductDescription = "Chechen filled dumplings served as a traditional meal.", Price = 13.99m, ImageUrl = "/food-pics/chechen-food/kurznesh.jpg", CategoryId = 7, Rating = 4 },
                new Product { ProductId = 26, ProductName = "Honey Cake", ProductDescription = "Layered honey cake with sweet cream filling.", Price = 8.99m, ImageUrl = "/food-pics/chechen-food/honeycake.jpg", CategoryId = 7, Rating = 5 }
            );
        }
    }
}