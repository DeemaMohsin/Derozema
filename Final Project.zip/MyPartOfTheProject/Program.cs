using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using MyPartOfTheProject.Data;

namespace MyPartOfTheProject
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Security / Identity database
            var securityConnection = builder.Configuration.GetConnectionString("SecurityServer")
                ?? throw new InvalidOperationException("Connection string 'SecurityServer' not found.");

            builder.Services.AddDbContext<IdentityContext>(options =>
                options.UseSqlServer(securityConnection));

            builder.Services.AddDatabaseDeveloperPageExceptionFilter();

            builder.Services.AddDefaultIdentity<ApplicationUser>(options =>
            {
                options.SignIn.RequireConfirmedAccount = false;
            })
            .AddRoles<IdentityRole>()
            .AddEntityFrameworkStores<IdentityContext>();

            // Restaurant database
            var restaurantConnection = builder.Configuration.GetConnectionString("RestaurantServer")
                ?? throw new InvalidOperationException("Connection string 'RestaurantServer' not found.");

            builder.Services.AddDbContext<DataContext>(options =>
                options.UseSqlServer(restaurantConnection));

            builder.Services.AddSession();

            builder.Services.AddControllersWithViews();
            builder.Services.AddRazorPages();

            var app = builder.Build();

            // Create Admin/User roles and default admin account
            using (var scope = app.Services.CreateScope())
            {
                var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
                var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

                string[] roles = { "Admin", "User" };

                foreach (var role in roles)
                {
                    if (!roleManager.RoleExistsAsync(role).Result)
                    {
                        roleManager.CreateAsync(new IdentityRole(role)).Wait();
                    }
                }

                string adminEmail = "admin@globaltaste.com";
                string adminPassword = "Admin123!";

                var adminUser = userManager.FindByEmailAsync(adminEmail).Result;

                if (adminUser == null)
                {
                    adminUser = new ApplicationUser
                    {
                        UserName = adminEmail,
                        Email = adminEmail,
                        EmailConfirmed = true
                    };

                    userManager.CreateAsync(adminUser, adminPassword).Wait();
                    userManager.AddToRoleAsync(adminUser, "Admin").Wait();
                }
            }

            if (app.Environment.IsDevelopment())
            {
                app.UseMigrationsEndPoint();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.MapStaticAssets();

            app.UseRouting();

            app.UseSession();

            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}")
                .WithStaticAssets();

            app.MapRazorPages()
                .WithStaticAssets();

            app.Run();
        }
    }
}