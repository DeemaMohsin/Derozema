﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MyPartOfTheProject.Migrations.Restaurant
{
    /// <inheritdoc />
    public partial class SeedRestaurantData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "CategoryName", "Description" },
                values: new object[,]
                {
                    { 1, "Jordanian", "Traditional Jordanian dishes" },
                    { 2, "Korean", "Popular Korean food" },
                    { 3, "Turkish", "Traditional Turkish meals" },
                    { 4, "French", "French dishes and desserts" },
                    { 5, "Egyptian", "Classic Egyptian food" },
                    { 6, "Chinese", "Chinese meals and snacks" },
                    { 7, "Chechen", "Traditional Chechen food" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "CategoryId", "ImageUrl", "Price", "ProductDescription", "ProductName" },
                values: new object[,]
                {
                    { 1, 1, "/food-pics/jordanian-food/mansaf.jpg", 22.99m, "Traditional Jordanian lamb with rice and jameed sauce.", "Mansaf" },
                    { 2, 1, "/food-pics/jordanian-food/alrashoof.jpg", 12.99m, "A warm Jordanian dish made with lentils, yogurt, and bread.", "Al-Rashoof" },
                    { 3, 1, "/food-pics/jordanian-food/makmora.jpg", 15.99m, "Layered Jordanian bread filled with chicken, onions, and olive oil.", "Makmora" },
                    { 4, 2, "/food-pics/korean-food/kimbap.jpg", 9.99m, "Korean rice rolls filled with vegetables and other ingredients.", "Kimbap" },
                    { 5, 2, "/food-pics/korean-food/teokbokki.jpg", 10.99m, "Spicy Korean rice cakes cooked in a sweet and spicy sauce.", "Teokbokki" },
                    { 6, 2, "/food-pics/korean-food/friedchicken.jpg", 14.99m, "Crispy Korean fried chicken with a flavorful sauce.", "Korean Fried Chicken" },
                    { 7, 2, "/food-pics/korean-food/kimchipizza.jpg", 13.99m, "A fusion pizza topped with spicy kimchi and cheese.", "Kimchi Pizza" },
                    { 8, 3, "/food-pics/turkish-food/doner.jpg", 11.99m, "Turkish meat served with bread, vegetables, and sauce.", "Doner" },
                    { 9, 3, "/food-pics/turkish-food/kebap.jpg", 16.99m, "Grilled Turkish meat served with rice or bread.", "Kebap" },
                    { 10, 3, "/food-pics/turkish-food/lahmacun.jpg", 8.99m, "Thin Turkish flatbread topped with minced meat and spices.", "Lahmacun" },
                    { 11, 3, "/food-pics/turkish-food/manti.jpg", 12.99m, "Turkish dumplings served with yogurt and sauce.", "Manti" },
                    { 12, 3, "/food-pics/turkish-food/pide.jpg", 11.99m, "Turkish boat-shaped flatbread with cheese or meat filling.", "Pide" },
                    { 13, 4, "/food-pics/french-food/croissant.jpg", 4.99m, "A buttery French pastry with a flaky golden crust.", "Croissant" },
                    { 14, 4, "/food-pics/french-food/onionsoup.jpg", 8.99m, "Classic French onion soup with melted cheese.", "Onion Soup" },
                    { 15, 4, "/food-pics/french-food/ratatouille.jpg", 12.99m, "French vegetable dish cooked with herbs and olive oil.", "Ratatouille" },
                    { 16, 4, "/food-pics/french-food/steakfrites.jpg", 24.99m, "French steak served with crispy fries.", "Steak Frites" },
                    { 17, 5, "/food-pics/egypt-food/koshari.jpg", 9.99m, "Egyptian dish with rice, pasta, lentils, chickpeas, and tomato sauce.", "Koshari" },
                    { 18, 5, "/food-pics/egypt-food/ful.jpg", 6.99m, "Egyptian fava beans served with olive oil and spices.", "Ful Medames" },
                    { 19, 5, "/food-pics/egypt-food/fesikh.jpg", 13.99m, "Traditional Egyptian salted fish dish.", "Fesikh" },
                    { 20, 6, "/food-pics/chinese-food/dumplings.jpg", 10.99m, "Chinese dumplings filled with meat or vegetables.", "Dumplings" },
                    { 21, 6, "/food-pics/chinese-food/lambian.jpg", 12.99m, "Chinese hand-pulled noodle dish.", "Lambian" },
                    { 22, 6, "/food-pics/chinese-food/friedbugs.jpg", 7.99m, "A unique Chinese street food snack.", "Fried Bugs" },
                    { 23, 7, "/food-pics/chechen-food/chepalgash.jpg", 9.99m, "Traditional Chechen flatbread stuffed with filling.", "Chepalgash" },
                    { 24, 7, "/food-pics/chechen-food/galnesh.jpg", 15.99m, "Chechen dumplings usually served with meat and garlic sauce.", "Galnesh" },
                    { 25, 7, "/food-pics/chechen-food/kurznesh.jpg", 13.99m, "Chechen filled dumplings served as a traditional meal.", "Kurznesh" },
                    { 26, 7, "/food-pics/chechen-food/honeycake.jpg", 8.99m, "Layered honey cake with sweet cream filling.", "Honey Cake" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 7);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 9);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 10);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 11);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 12);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 13);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 15);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 18);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 19);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 20);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 21);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 22);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 23);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 24);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 25);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "ProductId",
                keyValue: 26);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 5);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 6);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "CategoryId",
                keyValue: 7);
        }
    }
}
