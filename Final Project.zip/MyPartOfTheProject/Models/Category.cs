﻿using Microsoft.CodeAnalysis;
using System.ComponentModel.DataAnnotations;

namespace MyPartOfTheProject.Models
{
    public class Category
    {
        public int CategoryId { get; set; }

        [Required]
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; } = string.Empty;

        public string? Description { get; set; }

        public ICollection<Product> Products { get; set; } = new List<Product>();
    }
}
