﻿using System.ComponentModel.DataAnnotations;

namespace MyPartOfTheProject.Models
{
    public class OrderItem
    {
        public int OrderItemId { get; set; }

        [Range(1, 20)]
        public int Quantity { get; set; }

        public int OrderId { get; set; }

        public Order? Order { get; set; }

        public int ProductId { get; set; }

        public Product? Product { get; set; }
    }
}
