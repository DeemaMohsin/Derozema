﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyPartOfTheProject.Models
{
    public class Product
    {
        public int ProductId { get; set; }

        [Required]
        [Display(Name = "Food Name")]
        public string ProductName { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string? ProductDescription { get; set; }

        [Required]
        [Range(1, 100, ErrorMessage = "Price must be between 1 and 100.")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        [Display(Name = "Image")]
        public string? ImageUrl { get; set; }

        public int CategoryId { get; set; }

        public Category? Category { get; set; }

        [Range(1,5)]
        public int Rating { get; set; }
    }
}
