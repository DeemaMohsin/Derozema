﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MyPartOfTheProject.Models
{
    public enum PaymentMethod
    {
        Cash,
        Visa,
        MasterCard,
        PayPal
    }

    public enum PaymentStatus
    {
        Pending,
        Paid,
        Failed
    }
    public class Payment
    {
        public int PaymentId { get; set; }

        [Required]
        public int OrderId { get; set; }

        public Order? Order { get; set; }

        [Required]
        public PaymentMethod PaymentMethod { get; set; }

        [Required]
        public PaymentStatus PaymentStatus { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }
    }
}
